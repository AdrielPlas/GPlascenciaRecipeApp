package com.pjasoft.recipeapp.domain.dtos.utils

import androidx.compose.ui.focus.FocusManager

expect fun hideKeyboard(focusManager: FocusManager)