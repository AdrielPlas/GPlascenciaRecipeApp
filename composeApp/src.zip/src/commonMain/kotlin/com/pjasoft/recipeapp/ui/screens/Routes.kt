import kotlinx.serialization.Serializable


@Serializable
object LoginScreenRoute

@Serializable
object RegisterScreenRoute

@Serializable
object MainScreenGraph

@Serializable
object HomeScreenRoute

@Serializable
object MainScreenRoute